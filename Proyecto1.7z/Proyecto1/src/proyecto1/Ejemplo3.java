/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Jairo
 */
// .class; .pyc

public class Ejemplo3 {
    public static void main(String[] args) {
        String mensaje = "Hola";
        String mensaje2 = "Mundo";
        // System.out.println(mensaje+ "\n" +mensaje2);
        System.out.printf("%s\n\t%s", mensaje, mensaje2);
    }
}
