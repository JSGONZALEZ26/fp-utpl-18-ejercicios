/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Jairo
 */
// .class; .pyc
public class Ejemplo5 {

    public static void main(String[] args) {
        String nombre = "Jairo";
        String apellido = "González";
        int edad = 18;
        double valor = 242.82;
        // System.out.println(mensaje+ "\n" +mensaje2);
        System.out.printf("%s %s \n\tEdad: %d\n\t$ celular: %.2f\n", nombre, apellido.toUpperCase(), edad, valor);
    }
}
